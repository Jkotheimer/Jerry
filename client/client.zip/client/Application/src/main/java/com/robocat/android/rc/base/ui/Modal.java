package com.robocat.android.rc.base.ui;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.robocat.android.rc.R;

public class Modal extends DialogFragment {

    public enum Variant {
        CONFIRMATION,
        SUCCESS,
        ERROR
    };

    public static final String TITLE = "TITLE";
    public static final String MESSAGE = "MESSAGE";
    public static final String VARIANT = "VARIANT";

    private String mTitle;
    private String mMessage;
    private Variant mVariant;

    private Handler mHandler;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            mHandler = (Handler) context;
        } catch (ClassCastException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Dialog onCreateDialog(Bundle args) {
        this.mVariant = Variant.valueOf(args.getString(Modal.VARIANT, "ERROR"));
        this.mTitle = args.getString(Modal.TITLE, this.mVariant.equals(Variant.ERROR) ? "Error" : "Info");
        this.mMessage = args.getString(Modal.MESSAGE, this.mTitle);
        return (new AlertDialog.Builder(getActivity()))
                .setTitle(this.mTitle)
                .setMessage(this.mMessage)
                .setPositiveButton(R.string.modal_next, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mHandler.onNext(true);
                        dismiss();
                    }
                })
                .setNegativeButton(R.string.modal_back, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mHandler.onCancel();
                        dismiss();
                    }
                })
                .create();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.getting_started, container, false);
    }

    public interface Handler {
        public abstract void onCancel();
        public abstract void onBack();
        public abstract void onNext(boolean isFinished);
    }
}
