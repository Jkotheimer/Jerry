package com.robocat.android.rc.activities.base;

import android.app.Activity;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;

import com.robocat.android.rc.R;
import com.robocat.android.rc.services.BluetoothClassicService;
import com.robocat.android.rc.services.BluetoothConfiguration;
import com.robocat.android.rc.services.BluetoothService;
import com.robocat.android.rc.services.BluetoothStatus;

import java.util.ArrayList;
import java.util.UUID;

public abstract class BluetoothActivity extends AppCompatActivity {

    private static final int REQUEST_BLUETOOTH_PERMISSIONS = 0;
    private static final int REQUEST_BLUETOOTH_ENABLE = 1;

    protected BluetoothService mBluetoothService;
    protected ArrayList<BluetoothDevice> mFoundDevices;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mFoundDevices = new ArrayList<>();
        mBluetoothService = BluetoothService.getDefaultInstance();
        if (mBluetoothService == null) {
            BluetoothConfiguration config = new BluetoothConfiguration();
            config.uuid = UUID.fromString("ebc8e850-3d0c-4231-42c5-3031a583d47f");
            config.deviceName = this.getResources().getString(R.string.app_name);
            config.bluetoothServiceClass = BluetoothClassicService.class;
            config.context = getApplicationContext();
            config.callListenersInMainThread = true;
            config.characterDelimiter = '\n';
            config.bufferSize = 1024;
            BluetoothService.init(config);
            mBluetoothService = BluetoothService.getDefaultInstance();
        }
        if (mBluetoothService == null) {
            // TODO Throw error
            return;
        }
        mBluetoothService.setOnScanCallback(mBluetoothScanCallback);
        mBluetoothService.setOnEventCallback(mBluetoothEventCallback);
    }

    protected BluetoothStatus getBluetoothStatus() {
        return mBluetoothService.getStatus();
    }

    protected abstract void onBluetoothEnabled();
    protected abstract void onBluetoothPermissionGranted();
    protected abstract void onBluetoothServiceStart();
    protected void onDeviceFound(BluetoothDevice device, int rssi) {
        mFoundDevices.add(device);
    }

    protected void requestBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            this.requestPermissions(BluetoothService.permissions, REQUEST_BLUETOOTH_PERMISSIONS);
        } else {
            System.out.println("Permissions to be implemented");
        }
    }

    protected void requestBluetoothEnabled() {
        startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQUEST_BLUETOOTH_ENABLE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        boolean success = (Activity.RESULT_OK == resultCode);
        if (REQUEST_BLUETOOTH_ENABLE == requestCode) {
            if (success) {
                onBluetoothEnabled();
            } else {
                requestBluetoothEnabled();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQUEST_BLUETOOTH_PERMISSIONS) {
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    requestBluetoothPermission();
                    return;
                }
            }
        }
        onBluetoothPermissionGranted();
    }

    private void attachService() {
        Intent serviceIntent = new Intent(this, BluetoothClassicService.class);
        bindService(serviceIntent, mConnection, Service.BIND_AUTO_CREATE);
    }

    private void detachService() {
        unbindService(mConnection);
    }

    private final ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mBluetoothService = BluetoothService.getDefaultInstance();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
        }
    };

    private final BluetoothService.OnBluetoothScanCallback mBluetoothScanCallback = new BluetoothService.OnBluetoothScanCallback() {
        @Override
        public void onDeviceDiscovered(BluetoothDevice device, int rssi) {
            onDeviceFound(device, rssi);
        }
        @Override
        public void onStartScan() {

        }
        @Override
        public void onStopScan() {

        }
    };

    private final BluetoothService.OnBluetoothEventCallback mBluetoothEventCallback = new BluetoothService.OnBluetoothEventCallback() {
        @Override
        public void onDataRead(byte[] buffer, int length) {

        }
        @Override
        public void onStatusChange(BluetoothStatus status) {

        }
        @Override
        public void onDeviceName(String deviceName) {

        }
        @Override
        public void onToast(String message) {

        }
        @Override
        public void onDataWrite(byte[] buffer) {

        }
    };
}
