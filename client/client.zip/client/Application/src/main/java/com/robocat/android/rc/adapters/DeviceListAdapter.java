package com.robocat.android.rc.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.robocat.android.rc.R;
import com.robocat.android.rc.persistence.entities.RemoteDevice;

import java.util.ArrayList;
import java.util.List;

public class DeviceListAdapter extends ArrayAdapter<RemoteDevice> implements View.OnClickListener {

    private ArrayList<RemoteDevice> mDevices;
    Context mContext;

    private static class ViewHolder {
        TextView name;
        TextView uuid;
    }

    /**
     * Constructor
     *
     * @param context            The current context.
     * @param resource           The resource ID for a layout file containing a layout to use when
     *                           instantiating views.
     * @param objects            The objects to represent in the ListView.
     */
    public DeviceListAdapter(@NonNull Context context, int resource, @NonNull List<RemoteDevice> objects) {
        super(context, resource, objects);
        mContext = context;
        mDevices = (ArrayList<RemoteDevice>) objects;
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        RemoteDevice device = (RemoteDevice) getItem((Integer) v.getTag());
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder;

        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.device_list_item, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.name = (TextView) convertView.findViewById(R.id.device_name);
            viewHolder.uuid = (TextView) convertView.findViewById(R.id.device_uuid);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        RemoteDevice device = (RemoteDevice) getItem(position);
        viewHolder.name.setText(device.name);
        viewHolder.uuid.setText(device.uuid.toString());

        return convertView;
    }
}
