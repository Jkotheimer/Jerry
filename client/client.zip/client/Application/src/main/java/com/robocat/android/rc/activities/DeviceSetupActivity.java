package com.robocat.android.rc.activities;

import android.bluetooth.BluetoothDevice;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.robocat.android.rc.R;
import com.robocat.android.rc.activities.base.BluetoothActivity;
import com.robocat.android.rc.adapters.DeviceListAdapter;
import com.robocat.android.rc.base.ui.Modal;
import com.robocat.android.rc.persistence.entities.RemoteDevice;
import com.robocat.android.rc.services.BluetoothService;
import com.robocat.android.rc.services.BluetoothStatus;

import java.util.ArrayList;
import java.util.Arrays;

public class DeviceSetupActivity extends BluetoothActivity implements Modal.Handler {

    public static final String ACTION_GETTING_STARTED = "ACTION_GETTING_STARTED";
    public static final String ACTION_CONNECT_NEW_DEVICE = "ACTION_CONNECT_NEW_DEVICE";

    ListView mListView;
    private DeviceListAdapter mListAdapter;
    private ArrayList<RemoteDevice> mDevices;

    Runnable mBlockedBluetoothAction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mListView = (ListView) findViewById(R.id.device_list);
        mListAdapter = new DeviceListAdapter(getApplicationContext(), R.layout.device_list_item, mDevices);

        String action = this.getIntent().getAction();
        if (ACTION_GETTING_STARTED.equals(action)) {
            setContentView(R.layout.getting_started);
        } else {
            setContentView(R.layout.device_list);
        }

        BluetoothStatus bluetoothStatus = mBluetoothService.getStatus();
        if (BluetoothStatus.OFF.equals(bluetoothStatus)) {
            requestBluetoothEnabled();
        }
        if (BluetoothStatus.REQUIRES_PERMISSION.equals(bluetoothStatus)) {
        }
    }

    @Override
    protected void onBluetoothServiceStart() {}

    @Override
    protected void onBluetoothEnabled() {
        if (mBlockedBluetoothAction != null) {
            mBlockedBluetoothAction.run();
            mBlockedBluetoothAction = null;
        }
    }

    @Override
    protected void onBluetoothPermissionGranted() {
        if (mBlockedBluetoothAction != null) {
            mBlockedBluetoothAction.run();
            mBlockedBluetoothAction = null;
        }
    }

    public void onClickGetStarted(View v) {
        BluetoothStatus bluetoothStatus = getBluetoothStatus();
        if (BluetoothStatus.ON.equals(bluetoothStatus)) {
            mBluetoothService.startScan();
            setContentView(R.layout.device_list);
            return;
        } else if (BluetoothStatus.CONNECTING.equals(bluetoothStatus) || BluetoothStatus.CONNECTED.equals(bluetoothStatus)) {
            mBluetoothService.disconnect();
            mBluetoothService.startScan();
        } else if (BluetoothStatus.NOT_SUPPORTED.equals(bluetoothStatus)) {
            return;
        }
        mBlockedBluetoothAction = new Runnable() {
            @Override
            public void run() {
                mBluetoothService.startScan();
                setContentView(R.layout.device_list);
            }
        };
        if (BluetoothStatus.REQUIRES_PERMISSION.equals(bluetoothStatus)) {
            requestBluetoothPermission();
        } else if (BluetoothStatus.OFF.equals(bluetoothStatus)) {
            requestBluetoothEnabled();
        }
    }

    @Override
    protected void onDeviceFound(BluetoothDevice device, int rssi) {
        System.out.println("Found Device!");
        System.out.println(Arrays.toString(device.getUuids()));
        System.out.println(device.getName());
        System.out.println(device.getAddress());
        System.out.println(device.getType());
        RemoteDevice dev = new RemoteDevice(device.getUuids()[0].getUuid(), device.getName());
        mDevices.add(dev);
    }

    /**
     * ------------------------------------------
     *               MODAL HANDLER
     * ------------------------------------------
     */
    @Override
    public void onCancel() {

    }

    @Override
    public void onBack() {

    }

    @Override
    public void onNext(boolean isFinished) {

    }

    /**
     * Called when pointer capture is enabled or disabled for the current window.
     *
     * @param hasCapture True if the window has pointer capture.
     */
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }
}
