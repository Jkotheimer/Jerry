package com.robocat.android.rc.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.ProgressBar;

import com.robocat.android.rc.R;
import com.robocat.android.rc.persistence.ApplicationDatabase;
import com.robocat.android.rc.persistence.entities.RemoteDevice;
import com.robocat.android.rc.persistence.entities.RemoteDeviceDao;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.disposables.Disposable;
import io.reactivex.observers.DisposableSingleObserver;

public class StartupActivity extends Activity {

    private final long TIMEOUT_MILLIS = 10000;

    private ProgressBar mSpinner;
    private RemoteDeviceDao mDAO;
    private Disposable mDatabaseDisposable;

    @Override
    public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);
        this.setContentView(R.layout.spinner);

        mSpinner = (ProgressBar) findViewById(R.id.overlaySpinner);
        mSpinner.setVisibility(View.VISIBLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mSpinner.setMin(0);
        }
        mSpinner.setMax(1);

        mDAO = ApplicationDatabase.getInstance(this.getApplicationContext()).remoteDeviceDao();

        mDatabaseDisposable = mDAO.getAllRemoteDevices().subscribeWith(new DisposableSingleObserver<List<RemoteDevice>>() {
            @Override
            public void onSuccess(List<RemoteDevice> remoteDevices) {
                mSpinner.incrementProgressBy(1);
                Intent intent;
                if (remoteDevices.isEmpty()) {
                    intent = new Intent(StartupActivity.this, DeviceSetupActivity.class);
                    intent.setAction(DeviceSetupActivity.ACTION_GETTING_STARTED);
                } else {
                    intent = new Intent(StartupActivity.this, HomepageActivity.class);
                    intent.putParcelableArrayListExtra(
                            HomepageActivity.EXTRA_REMOTE_DEVICES,
                            (ArrayList<RemoteDevice>) remoteDevices
                    );
                    intent.setAction(HomepageActivity.ACTION_CONTINUE_PROGRESS);
                }
                startActivity(intent);
            }
            @Override
            public void onError(Throwable e) {
                startActivity(new Intent(HomepageActivity.ACTION_GETTING_STARTED));
            }
        });

        try {
            Thread.sleep(this.TIMEOUT_MILLIS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        this.mDatabaseDisposable.dispose();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        this.mDatabaseDisposable.dispose();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }
}
